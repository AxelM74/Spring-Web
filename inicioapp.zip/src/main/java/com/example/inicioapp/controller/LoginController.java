package com.example.inicioapp.controller;

import com.example.inicioapp.model.Usuario;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class LoginController {

    @GetMapping("/inicio")
    public String mostrarFormulario(Model model, @RequestParam(required = false) String error) {
        model.addAttribute("usuario", new Usuario());
        if ("true".equals(error)) {
            model.addAttribute("mensaje", "Usuario o contraseña incorrectos");
        }
        return "inicio";
    }

    @PostMapping("/inicio")
    public String procesarFormulario(@ModelAttribute Usuario usuario, Model model) {
        // Simulamos usuario válido
        if ("admin01".equals(usuario.getUsuario()) && "am1234".equals(usuario.getContrasena())) {
            model.addAttribute("nombreUsuario", usuario.getUsuario());
            return "bienvenida";
        } else {
            return "redirect:/inicio?error=true";
        }
    }
}